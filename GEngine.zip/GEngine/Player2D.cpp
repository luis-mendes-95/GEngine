#include "Player2D.h"

Player2D::Player2D()
{
	sprite = new Sprite("Resources/Player2D.png");
	projectile = new Image("Resources/projectile.png");

	vel = 0;
}

Player2D::~Player2D()
{
}

void Player2D::Update()
{
	/*IF ARROWS OR WASD IS DOWN, MOVE THE PLAYER AROUND*/
}

void Player2D::Draw()
{
	sprite->Draw(x, y, z);
}
