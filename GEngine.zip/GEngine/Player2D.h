#ifndef _THISGAME_PLAYER_H_
#define _THISGAME_PLAYER_H_

/*INCLUS�ES*/

#include "Types.h"
#include "Object.h"
#include "Sprite.h"

class Player2D : public Object
{
private:
	Sprite * sprite;
	Image* projectile;
	float vel;
	bool keyCtrl;
	bool leftArrow;
	bool rightArrow;
	bool aKeyDown;
	bool dKeyDown;

public:
	Player2D();
	~Player2D();

	void Update();
	void Draw();
};














#endif